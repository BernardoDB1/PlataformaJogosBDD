drop database legendary_games;
CREATE DATABASE legendary_games;
use legendary_games;

CREATE TABLE usuarios (
  usuarios_id INT NOT NULL AUTO_INCREMENT,
  email VARCHAR(45) NOT NULL,
  senha VARCHAR(45) NOT NULL,
  apelido CHAR NOT NULL,
  usuarioscol VARCHAR(45) NOT NULL,
  PRIMARY KEY (usuarios_id));

CREATE TABLE pagamentos (
  pagamento_id INT NOT NULL AUTO_INCREMENT,
  forma_pagamento CHAR NOT NULL,
  pagamento_data DATETIME NOT NULL,
  reembolso DATETIME NOT NULL,
  PRIMARY KEY (pagamento_id));

CREATE TABLE jogos (
  jogos_id INT NOT NULL AUTO_INCREMENT,
  faixa_etaria INT NOT NULL,
  avaliacao FLOAT NOT NULL,
  usuarios_usuarios_id INT NOT NULL,
  jogo_nome CHAR NOT NULL,
  preco FLOAT NOT NULL,
  pagamentos_pagamento_id INT NOT NULL,
  PRIMARY KEY (jogos_id, usuarios_usuarios_id, pagamentos_pagamento_id),
  FOREIGN KEY (pagamentos_pagamento_id)
  REFERENCES pagamentos (pagamento_id));

CREATE TABLE forum (
  forum_id INT NOT NULL AUTO_INCREMENT,
  envio_comentario LONGTEXT NOT NULL,
  avalia_comentario INT NOT NULL,
  PRIMARY KEY (forum_id));

CREATE TABLE usuarios_has_forum (
  usuarios_usuarios_id INT NOT NULL,
  forum_forum_id INT NOT NULL,
  PRIMARY KEY (usuarios_usuarios_id, forum_forum_id),
  FOREIGN KEY (usuarios_usuarios_id)
  REFERENCES usuarios (usuarios_id), 
  FOREIGN KEY (forum_forum_id)
  REFERENCES forum (forum_id));

CREATE TABLE desenvolvedora (
  desenvolvedora_id INT NOT NULL AUTO_INCREMENT,
  biblioteca_jogos INT NOT NULL,
  desenvolvedora_nome CHAR(999) NOT NULL,
  desenvolvedora_regiao CHAR(999) NOT NULL,
  premiacoes VARCHAR(45) NOT NULL,
  PRIMARY KEY (desenvolvedora_id));

CREATE TABLE jogos_has_desenvolvedora (
  jogos_jogos_id INT NOT NULL,
  jogos_usuarios_usuarios_id INT NOT NULL,
  desenvolvedora_desenvolvedora_id INT NOT NULL,
  plataformajogo VARCHAR(45) NOT NULL,
  PRIMARY KEY (jogos_jogos_id, jogos_usuarios_usuarios_id, desenvolvedora_desenvolvedora_id),
  FOREIGN KEY (jogos_jogos_id, jogos_usuarios_usuarios_id)
  REFERENCES jogos (jogos_id, usuarios_usuarios_id),
  FOREIGN KEY (desenvolvedora_desenvolvedora_id)
  REFERENCES desenvolvedora (desenvolvedora_id));

CREATE TABLE jogos_has_usuarios (
  jogos_jogos_id INT NOT NULL,
  jogos_usuarios_usuarios_id INT NOT NULL,
  usuarios_usuarios_id INT NOT NULL,
  PRIMARY KEY (jogos_jogos_id, jogos_usuarios_usuarios_id, usuarios_usuarios_id),
  FOREIGN KEY (jogos_jogos_id, jogos_usuarios_usuarios_id)
  REFERENCES jogos (jogos_id , usuarios_usuarios_id),
  FOREIGN KEY (usuarios_usuarios_id)
  REFERENCES usuarios (usuarios_id));
  
insert into pagamentos (forma_pagamento, pagamento_data, reembolso) values ('PayPal', '2019/01/25', false);
	insert into pagamentos (forma_pagamento, pagamento_data, reembolso) values ('Crédito', '2022/08/20', false);
	insert into pagamentos (forma_pagamento, pagamento_data, reembolso) values ('Boleto', '2021/09/26', true);
	insert into pagamentos (forma_pagamento, pagamento_data, reembolso) values ('PayPal', '2019/05/31', false);
	insert into pagamentos (forma_pagamento, pagamento_data, reembolso) values ('Débito', '2019/03/25', true);
	insert into pagamentos (forma_pagamento, pagamento_data, reembolso) values ('Boleto', '2017/01/09', true);
	insert into pagamentos (forma_pagamento, pagamento_data, reembolso) values ('Crédito', '2020/10/06', true);
	insert into pagamentos (forma_pagamento, pagamento_data, reembolso) values ('Pix', '2017/02/03', true);
	insert into pagamentos (forma_pagamento, pagamento_data, reembolso) values ('PayPal', '2020/02/02', false);
	insert into pagamentos (forma_pagamento, pagamento_data, reembolso) values ('Crédito', '2019/03/10', true);
    
insert into jogos (faixa_etaria, avaliacao, preco, jogo_nome) values ('14', 0.2, 158.23, 'Tresom');
	insert into jogos (faixa_etaria, avaliacao, preco, jogo_nome) values ('14', 2.6, 360.93, 'Home Ing');
	insert into jogos (faixa_etaria, avaliacao, preco, jogo_nome) values ('10', 3.1, 367.96, 'Matsoft');
	insert into jogos (faixa_etaria, avaliacao, preco, jogo_nome) values ('12', 1.4, 190.21, 'Y-Solowarm');
	insert into jogos (faixa_etaria, avaliacao, preco, jogo_nome) values ('14', 4.5, 380.75, 'Sonsing');
	insert into jogos (faixa_etaria, avaliacao, preco, jogo_nome) values ('L', 3.7, 93.57, 'Flexidy');
	insert into jogos (faixa_etaria, avaliacao, preco, jogo_nome) values ('14', 2.2, 152.04, 'Andalax');
	insert into jogos (faixa_etaria, avaliacao, preco, jogo_nome) values ('12', 4.8, 118.27, 'Z-Solowarm');
	insert into jogos (faixa_etaria, avaliacao, preco, jogo_nome) values ('10', 1.2, 420.73, 'Bytecard');
	insert into jogos (faixa_etaria, avaliacao, preco, jogo_nome) values ('14', 4.4, 134.59, 'Solarbreeze');

insert into usuarios (email, senha, apelido) values ('rfosten0@webeden.co.uk', 'CzXOs3UD5Oaa', 'ebeddie0');
	insert into usuarios (email, senha, apelido) values ('jbrogden1@goodreads.com', 'p7pv6UbSH', 'eforce1');
	insert into usuarios (email, senha, apelido) values ('thardson2@bizjournals.com', 'gU24YP', 'saulton2');
	insert into usuarios (email, senha, apelido) values ('imenier3@newsvine.com', 'C0PKQv3', 'nhaldenby3');
	insert into usuarios (email, senha, apelido) values ('rmoreby4@bing.com', 'rLI08YP2p', 'jdilucia4');
	insert into usuarios (email, senha, apelido) values ('trioch5@geocities.com', '4GxnMe', 'bsmullin5');
	insert into usuarios (email, senha, apelido) values ('lsteckings6@google.pl', 'HAk1ucjjb', 'drodenhurst6');
	insert into usuarios (email, senha, apelido) values ('ejodlkowski7@ustream.tv', 'PWiZy9vfJ', 'ntomowicz7');
	insert into usuarios (email, senha, apelido) values ('atrevithick8@mapy.cz', 'jDqxuU9ivvR', 'cpettwood8');
	insert into usuarios (email, senha, apelido) values ('mpoppy9@samsung.com', 'tjlfIJHXo', 'vcarous9');